/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package wazu_comunity;


import java.io.*;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Properties;
import javax.net.ssl.*;
/**
 *
 * @author lelguea
 */
public class Wazu_Comunity {
    /**
     * @param args the command line arguments
     */
    
    static String HOST="wazuh.XXXXXXXX:55000";
    static String PROTOCOLO="https://";
    static boolean DETALLE=true;
    
    static String Busca="Java";
    
    
    public static void main(String[] args) {
        Properties defaultProps = System.getProperties(); //obtiene las "properties" del sistema
        defaultProps.put("java.net.preferIPv6Addresses", "false");

        
        try {

            URL wazuh=new URL(PROTOCOLO + HOST + "/security/user/authenticate?raw=true");
            String tr=proceso(wazuh, "wazuh-wui","d?dUASDADdfasfasfdasdfvj9TK");
            //System.out.println(tr);
            
            
            //String Agentes=get("/agents?q=group!=Equipos_Personales;group!=Revolucion&sort=name",tr);
            String Agentes=get("/agents",tr);
            
            ArrayList<String> agent=JsonDecoder.TraerAgentes(Agentes);
            int totVul=0;
            System.out.println("Hay "+agent.size()+" agentes");
            for (int i=0;i<agent.size();i++) {
                String id=agent.get(i).substring(0,3);
                String Vulnes=get("/vulnerability/"+id,tr);
                int realv=JsonDecoder.NumVulnerabilidades(Vulnes);
                int numvuln=JsonDecoder.Vulnerabilidades(Vulnes).size();
                if (numvuln>0) {
                    System.out.println("El agente "+agent.get(i)+" tiene "+realv+" vulnerabilidad");
                    totVul=totVul+realv;
                    if (DETALLE) {
                        Detalle(id, tr);
                    }
                    if (Busca.length()>0) {
                        ArrayList<String> busca = JsonDecoder.BuscaVulnerabilidades(Vulnes, Busca);
                        for (int x=0;x<busca.size();x++) {
                            System.out.println(busca.get(x));
                        }
                    }
                    //System.out.println("\n");
                } else {
                    if (DETALLE) {
                        System.out.println("El agente "+agent.get(i)+" tiene "+realv+" vulnerabilidad");
                    }
                }
            }
            System.out.println("Total de Vulnerabilidades: "+totVul);
        } catch (IOException ex) {
            System.err.println(ex.toString());
        }
    }
    
    public static String proceso (URL cadenaURL, String Usuario, String Pass) {
        
        String Salida="";
        
        HttpsURLConnection.setDefaultHostnameVerifier(new InvalidCertificateHostVerifier());
        try {
            HttpsURLConnection conn = (HttpsURLConnection) cadenaURL.openConnection();
            
            SSLContext sc = SSLContext.getInstance("SSL"); 
            sc.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());  
            
            conn.setSSLSocketFactory(sc.getSocketFactory());
            HostnameVerifier allHostsValid = (String hostname, SSLSession session) -> true;
            
            conn.setHostnameVerifier(allHostsValid);
            conn.setRequestMethod("GET");
            
            String userpass = Usuario+":"+Pass;
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
            conn.setRequestProperty ("Authorization", basicAuth);
            String Token;
            try (InputStream in = conn.getInputStream()) {
                InputStreamReader ist=new InputStreamReader(in);
                Token = "";
                try (BufferedReader br = new BufferedReader(ist)) {
                    String input;
                    
                    while ((input = br.readLine()) != null){
                        Token=input;
                        //System.out.println(input);
                    }
                    //System.out.println();
                }
            }
            conn.disconnect();
            //System.out.println("El Token es "+Token);
            Salida=Token;
                        
        } catch (IOException | KeyManagementException | NoSuchAlgorithmException ex) {
            System.err.println(ex.toString());
        }
        return Salida;
        
    }

    public static String get(String cadena, String Token) {
        HttpsURLConnection.setDefaultHostnameVerifier(new InvalidCertificateHostVerifier());
        String Salida="";
        
        try {
            URL sitio =new URL(PROTOCOLO + HOST + ""+cadena);
            HttpsURLConnection conn = (HttpsURLConnection) sitio.openConnection();
            
            SSLContext sc = SSLContext.getInstance("SSL"); 
            sc.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());  
            
            conn.setSSLSocketFactory(sc.getSocketFactory());
            
                    // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = (String hostname, SSLSession session) -> true;
            conn.setHostnameVerifier(allHostsValid);
            conn.setRequestMethod("GET");
            conn.addRequestProperty("Authorization", "Bearer "+Token);
            //System.out.println(conn.getResponseCode());
            InputStream in = conn.getInputStream();
            InputStreamReader ist=new InputStreamReader(in);

            
            try (BufferedReader br = new BufferedReader(ist)) {
                String input;
                
                while ((input = br.readLine()) != null){
                    //System.out.println(input);
                    Salida=Salida+input;
                }
                //System.out.println();
            }
        } catch (IOException | KeyManagementException | NoSuchAlgorithmException ex) {
            System.out.println(ex.toString());
        }
        return Salida;
    }  
    
    public static void Detalle(String Agente, String tr) {

        String Vulnes=get("/vulnerability/"+Agente,tr);
        ArrayList<String> detalle=JsonDecoder.VulnerabilidadesDetalles(Vulnes);
        int numvuln=detalle.size();
        if (numvuln>0) {
        for (int i=0;i<detalle.size();i++) {
                System.out.println("\t"+detalle.get(i));
            }
        }
    }

}
