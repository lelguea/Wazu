/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package wazu_comunity;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author lelguea
 */
public class JsonDecoder {
    
    static boolean DETALLEURL=false;

    public static ArrayList<String> TraerAgentes(String Cadena) {
        
        JSONParser parser = new JSONParser();
        ArrayList<String> Salida=new ArrayList<>();
        
        try {
        
            JSONObject jsonObject = (JSONObject) parser.parse(Cadena);
            //System.out.println(jsonObject);

            
            Object datos = jsonObject.get("data");
            //System.out.println(datos);
            
            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());

            
            long total_failed_items = (Long) ODatos.get("total_failed_items");
            //System.out.println(total_failed_items);
            long total_affected_items = (Long) ODatos.get("total_affected_items");
            //System.out.println(total_affected_items);
            
            Object afectados= ODatos.get("affected_items");
            //System.out.println(afectados);
            

            // loop array
            JSONArray msg = (JSONArray) ODatos.get("affected_items");
            Iterator<JSONObject> iterator = msg.iterator();
            while (iterator.hasNext()) {
                
                JSONObject temp=iterator.next();
                if (!temp.get("id").toString().contains("000")) {
                    Salida.add(temp.get("id")+" ("+temp.get("name")+")");
                }
            }

        } catch (org.json.simple.parser.ParseException e) {
            System.err.println(e.toString());
        }
        
        return Salida;

    }
    
    public static ArrayList<String> TraerGrupos(String Cadena) {
        
        JSONParser parser = new JSONParser();
        ArrayList<String> Salida=new ArrayList<>();
        
        try {
        
            JSONObject jsonObject = (JSONObject) parser.parse(Cadena);
            Object datos = jsonObject.get("data");
            
            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());

            
            Object afectados= ODatos.get("affected_items");
            JSONArray msg = (JSONArray) ODatos.get("affected_items");
            Iterator<JSONObject> iterator = msg.iterator();
            while (iterator.hasNext()) {
                
                JSONObject temp=iterator.next();
                Salida.add(temp.get("name")+" ("+temp.get("count")+")");
            }

        } catch (org.json.simple.parser.ParseException e) {
            System.err.println(e.toString());
        }
        
        return Salida;

    }

    public static int NumVulnerabilidades(String Cadena) {
        JSONParser parser = new JSONParser();
        int Salida=0;
        
        try {
        
            JSONObject jsonObject = (JSONObject) parser.parse(Cadena);
            //System.out.println(jsonObject);

            
            Object datos = jsonObject.get("data");
            //System.out.println(datos);
            
            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());

            
            long total_failed_items = (Long) ODatos.get("total_failed_items");
            //System.out.println(total_failed_items);
            Long total_affected_items = (Long) ODatos.get("total_affected_items");
            Salida= total_affected_items.intValue();
            
        } catch (ParseException ex) {
            System.err.println(ex.toString());
        }
        return Salida;
    }

        public static ArrayList<String> TraerResumen(String Cadena) {
        JSONParser parser = new JSONParser();
        ArrayList<String> Salida=new ArrayList<>();
        
        try {
        
            JSONObject jsonObject = (JSONObject) parser.parse(Cadena);
            Object datos = jsonObject.get("data");
            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());
           
            Object severidad =  ODatos.get("severity");
            //System.out.println(severidad.toString());
            
            JSONObject seve=(JSONObject) parser.parse(severidad.toString());
            
            if (seve.get("Critical") == null) {
                Salida.add("Critica: "+0);
            } else {
                Salida.add("Critica: "+seve.get("Critical"));
            }
            
            if (seve.get("High")==null) {
                Salida.add("Alta: "+0);
            } else {
                Salida.add("Alta: "+seve.get("High"));
            }
            
            if (seve.get("Medium")==null) {
                Salida.add("Media: "+0);
            } else {
                Salida.add("Media: "+seve.get("Medium"));
            }
            
            if (seve.get("Low")==null) {
                Salida.add("Baja: "+0);
            } else {
                Salida.add("Baja: "+seve.get("Low"));
            }
            




            
        } catch (ParseException ex) {
            System.err.println(ex.toString());
        }
        return Salida;
    }

    
    public static ArrayList<String> Vulnerabilidades(String Cadena) {
        JSONParser parser = new JSONParser();
        ArrayList<String> Salida=new ArrayList<>();
        
        try {
        
            JSONObject jsonObject = (JSONObject) parser.parse(Cadena);
            //System.out.println(jsonObject);

            
            Object datos = jsonObject.get("data");
            //System.out.println(datos);
            
            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());

            
            long total_failed_items = (Long) ODatos.get("total_failed_items");
            //System.out.println(total_failed_items);
            long total_affected_items = (Long) ODatos.get("total_affected_items");

            Object afectados= ODatos.get("affected_items");
            //System.out.println(afectados);
            

            // loop array
            JSONArray msg = (JSONArray) ODatos.get("affected_items");
            //System.out.println("****"+msg.toString());
            Iterator<JSONObject> iterator = msg.iterator();
            while (iterator.hasNext()) {
                JSONObject temp=iterator.next();
                String refes=temp.get("external_references").toString();
                Salida.add(temp.get("title")+" ("+temp.get("severity")+") cvss3_score:"+temp.get("cvss3_score")+" "+JsonDecoder.Referencias(refes).get(0));
            }

        } catch (org.json.simple.parser.ParseException e) {
            System.err.println(e.toString());
        }
        return Salida;
    }

    public static ArrayList<String> VulnerabilidadesCortas(String Cadena) {
        JSONParser parser = new JSONParser();
        ArrayList<String> Salida=new ArrayList<>();
        
        try {
        
            JSONObject jsonObject = (JSONObject) parser.parse(Cadena);
            //System.out.println(jsonObject);

            
            Object datos = jsonObject.get("data");
            //System.out.println(datos);
            
            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());

            
            long total_failed_items = (Long) ODatos.get("total_failed_items");
            //System.out.println(total_failed_items);
            long total_affected_items = (Long) ODatos.get("total_affected_items");

            Object afectados= ODatos.get("affected_items");
            //System.out.println(afectados);
            

            // loop array
            JSONArray msg = (JSONArray) ODatos.get("affected_items");
            //System.out.println("****"+msg.toString());
            Iterator<JSONObject> iterator = msg.iterator();
            while (iterator.hasNext()) {
                JSONObject temp=iterator.next();
                //String refes=temp.get("external_references").toString();
                Salida.add(temp.get("title")+" ("+temp.get("severity")+")");
            }

        } catch (org.json.simple.parser.ParseException e) {
            System.err.println(e.toString());
        }
        return Salida;
    }


    
    public static ArrayList<String> VulnerabilidadesDetalles(String Cadena) {
        JSONParser parser = new JSONParser();
        ArrayList<String> Salida=new ArrayList<>();
        
        try {
        
            JSONObject jsonObject = (JSONObject) parser.parse(Cadena);
            
            Object datos = jsonObject.get("data");
            
            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());
            
            long total_failed_items = (Long) ODatos.get("total_failed_items");
            long total_affected_items = (Long) ODatos.get("total_affected_items");
            
            Object afectados= ODatos.get("affected_items");
            

            JSONArray msg = (JSONArray) ODatos.get("affected_items");
            Iterator<JSONObject> iterator = msg.iterator();
            while (iterator.hasNext()) {
                JSONObject temp=iterator.next();
                String refes=temp.get("external_references").toString();
                ArrayList<String> URLs=JsonDecoder.Referencias(refes);
                //if (temp.get("title").toString().contains(Titulo)) { //&& temp.get("severity").toString().contains("Critical")) {
                if (temp.get("severity").toString().contains("Critical")) {
                    Salida.add(temp.get("title")+" ("+temp.get("severity")+") cvss3_score:"+temp.get("cvss3_score"));
                    if (DETALLEURL) {
                        for (int i=0;i<URLs.size();i++) {
                            Salida.add("\t"+URLs.get(i));
                        }
                    }
                }
            }

        } catch (org.json.simple.parser.ParseException e) {
            System.err.println(e.toString());
        }
        return Salida;
    }
    

    public static ArrayList<String> BuscaVulnerabilidades(String Cadena, String Titulo) {
        JSONParser parser = new JSONParser();
        ArrayList<String> Salida=new ArrayList<>();
        
        try {
        
            JSONObject jsonObject = (JSONObject) parser.parse(Cadena);
            
            Object datos = jsonObject.get("data");
            
            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());
            
            long total_failed_items = (Long) ODatos.get("total_failed_items");
            long total_affected_items = (Long) ODatos.get("total_affected_items");
            
            Object afectados= ODatos.get("affected_items");
            

            JSONArray msg = (JSONArray) ODatos.get("affected_items");
            Iterator<JSONObject> iterator = msg.iterator();
            while (iterator.hasNext()) {
                JSONObject temp=iterator.next();
                String refes=temp.get("external_references").toString();
                ArrayList<String> URLs=JsonDecoder.Referencias(refes);
                if (temp.get("title").toString().contains(Titulo)) { //&& temp.get("severity").toString().contains("Critical")) {
                    System.out.println(temp.get("title"));
                    Salida.add(temp.get("title")+" ("+temp.get("severity")+") cvss3_score:"+temp.get("cvss3_score"));
                } else {
                    //Salida.add("No se encontro ("+Titulo+")");
                }
            }

        } catch (org.json.simple.parser.ParseException e) {
            System.err.println(e.toString());
        }
        return Salida;
    }

    
    
    public static ArrayList<String> Referencias(String Cadena) {

        JSONParser parser = new JSONParser();
        ArrayList<String> Salida=new ArrayList<>();
        
        try {
        
            JSONArray msg = (JSONArray) parser.parse(Cadena);
            for (int i=0;i<msg.size();i++) {
                Salida.add(msg.get(i).toString());
            }
        } catch (org.json.simple.parser.ParseException e) {
            System.err.println(e.toString());
        }
        
        return Salida;
        
    }
    
    public static String Llave(String Cadena) {
        String Salida="";
        JSONParser parser = new JSONParser();
        
        try {
            JSONObject jsonObject = (JSONObject) parser.parse(Cadena);

            Object datos = jsonObject.get("data");
            //System.out.println(datos);

            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());

            JSONArray msg = (JSONArray) ODatos.get("affected_items");

            Iterator<JSONObject> iterator = msg.iterator();
            while (iterator.hasNext()) {
                JSONObject temp=iterator.next();
                //System.out.println("temp= "+temp);
                String key=temp.get("key").toString();
                //System.out.println("*********** -> "+key);
                Salida=key;
            }

        } catch (ParseException e) {
            System.err.println(e.toString());
        }
        
        byte[] decoded = Base64.getDecoder().decode(Salida);
        String deco=new String(decoded, StandardCharsets.UTF_8);
        deco=deco.substring(deco.length()-64, deco.length());
           
        return deco;
        
        
    }
    

    public static ArrayList<String> ReferenciasCVE(String Vulnerabilidad) {
        ArrayList<String> Salida= new ArrayList<>();
        JSONParser parser = new JSONParser();
        
        try {
        
            JSONObject jsonObject = (JSONObject) parser.parse(Vulnerabilidad);
            System.out.println(jsonObject);
            
            Object datos = jsonObject.get("data");
            System.out.println(datos);
            
            JSONObject ODatos=(JSONObject) parser.parse(datos.toString());
            JSONArray msg = (JSONArray) ODatos.get("affected_items");
            Iterator<JSONObject> iterator = msg.iterator();
            while (iterator.hasNext()) {
                JSONObject temp=iterator.next();
                String refes=temp.get("external_references").toString();
                ArrayList<String> URLs=JsonDecoder.Referencias(refes);
                for (int i=0;i<URLs.size();i++) {
                    Salida.add(URLs.get(i));
                }
            }
        } catch (ParseException e) {
            System.err.println(e.toString());
        }
        
        // De duplicamos (Quitamos los repe)
        
        //ArrayList<String> deduped = Salida.stream().distinct().collect(Collectors.toList());
        Set<String> set = new HashSet<>(Salida);
        Salida.clear();
        Salida.addAll(set);
        
        
        return Salida;
    }
    
    
}
